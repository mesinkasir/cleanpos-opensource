<!--<div class="pos-f-t">
 <nav class="navbar navbar-dark bg-dark fixed-top">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  <div class="collapse" id="navbarToggleExternalContent">
    <div class="bg-dark text-white text-center">
Open source point of sale free for you present by www.hockeycomputindo.com
    </div>
  </div></nav></div>-->
  <marquee direction="left" class="fixed-bottom">This is a open source point of sale you can freely change any code present by - <a href="https://www.hockeycomputindo.com" target="blank" class="text-secondary">www.hockeycomputindo.com</a> - <a href="https://mesinkasir.asia" target="blank" class="text-secondary">www.mesinkasir.asia</a> - <a href="https://www.fb.com/mesinkasircomplete" target="blank" class="text-secondary">www.fb.com/mesinkasircomplete</a></marquee>
  
  
  